package com.example.namrata.freeleticsgym;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class Tab1Fragment extends Fragment {

    private static String[] strings3 = {"Plate Twist","Pull Over","Pull Press","Push Press","Sl Deadlift",
            "Sumo Deadlift","Sumo Pull","Thruster","Tricep Extension","Upright row","wt dip","wt pull up"};

    public static Tab1Fragment newInstance() {
        Bundle args = new Bundle();
       Tab1Fragment fragment = new Tab1Fragment();
        fragment.setArguments(args);
        return fragment;
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View mainView = inflater.inflate(R.layout.fragment_tab1, container, false);
        ListView listView = (ListView) mainView.findViewById(R.id.listView);

      listView.setAdapter(new ArrayAdapter<String>(getActivity(),R.layout.simple_list_item_11,strings3));
        return mainView;
    }


}
