package com.example.namrata.freeleticsgym;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class Tab2Fragment extends Fragment {

    private static String[] strings1 = {"Strength","Conditioning","endurance","challenges"};
    public static Tab1Fragment newInstance() {
        Bundle args = new Bundle();
        Tab1Fragment fragment = new Tab1Fragment();
        fragment.setArguments(args);
        return fragment;
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View mainView = inflater.inflate(R.layout.fragment_tab2, container, false);
        ListView listView = (ListView) mainView.findViewById(R.id.listView);

        listView.setAdapter(new ArrayAdapter<String>(getActivity(),R.layout.simple_list_item_12,strings1));
        return mainView;
    }


}
